clear;clc;
load interaction.mat;
load FS.mat;
load FSP.mat;
load SS.mat;
load SSP.mat;
%interaction:the known RBP-AS event association
% FS:the functional similarity between RBP(i) and RBP(j)
% FSP:Functional similarity weighting matrix
% SS:the module similarity between AS(i) and AS(j).
% SSP:module similarity weighting matrix


RBP_AS_Y=interaction;
AS_Function_S=SS;
AS_Sem_S=SSP;
RBP_Function_S=FS;
RBP_Sequences_Needle_S=FSP;

K1 = [];
K1(:,:,1)=RBP_Function_S;
K1(:,:,2)=RBP_Sequences_Needle_S;
K2 = [];
K2(:,:,1)=AS_Function_S;
K2(:,:,2)=AS_Sem_S;
y = RBP_AS_Y;
%%%GIP for RBP and AS events
K1(:,:,3)=kernel_gip(y,1, 1);
K2(:,:,3)=kernel_gip(y,2, 1);
%%%Optimal weight for different similarity matrices
[weight_v1] = FKL_weights(K1,y,1,200);
%%%using the optimal weights to combine the similarity matrices
K_COM1 = combine_kernels(weight_v1, K1);		

[weight_v2] = FKL_weights(K2,y,2,200);
K_COM2 = combine_kernels(weight_v2, K2);
%%%denoise the integrated similarity matrice and applied IMC to get the predicted RBP-AS events association.	
score = LapIMC(K_COM1,K_COM2,y, 2^(-5),20,1);
	
	
